﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form7
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Panel1 = New Panel()
        Label1 = New Label()
        Button1 = New Button()
        Button2 = New Button()
        Button3 = New Button()
        Button4 = New Button()
        Button5 = New Button()
        Button6 = New Button()
        Button7 = New Button()
        Button8 = New Button()
        Button9 = New Button()
        Button10 = New Button()
        Button11 = New Button()
        Button12 = New Button()
        Button13 = New Button()
        Button14 = New Button()
        Button15 = New Button()
        Button16 = New Button()
        Panel1.SuspendLayout()
        SuspendLayout()
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.Green
        Panel1.Controls.Add(Button8)
        Panel1.Controls.Add(Button7)
        Panel1.Controls.Add(Button4)
        Panel1.Location = New Point(3, 1)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(356, 652)
        Panel1.TabIndex = 0
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI", 12F)
        Label1.Location = New Point(404, 72)
        Label1.Name = "Label1"
        Label1.Size = New Size(129, 32)
        Label1.TabIndex = 1
        Label1.Text = "Dashboard"
        ' 
        ' Button1
        ' 
        Button1.Location = New Point(396, 140)
        Button1.Name = "Button1"
        Button1.Size = New Size(252, 140)
        Button1.TabIndex = 2
        Button1.Text = "Total No Of Payments" & vbCrLf & "=" & vbCrLf
        Button1.UseVisualStyleBackColor = True
        ' 
        ' Button2
        ' 
        Button2.Location = New Point(697, 140)
        Button2.Name = "Button2"
        Button2.Size = New Size(252, 140)
        Button2.TabIndex = 3
        Button2.Text = "Total No Of Ride Used" & vbCrLf & "=" & vbCrLf
        Button2.UseVisualStyleBackColor = True
        ' 
        ' Button3
        ' 
        Button3.Location = New Point(987, 140)
        Button3.Name = "Button3"
        Button3.Size = New Size(252, 140)
        Button3.TabIndex = 4
        Button3.Text = "Total No Of Ticket Sold" & vbCrLf & "=" & vbCrLf
        Button3.UseVisualStyleBackColor = True
        ' 
        ' Button4
        ' 
        Button4.Location = New Point(9, 520)
        Button4.Name = "Button4"
        Button4.Size = New Size(328, 44)
        Button4.TabIndex = 5
        Button4.Text = "Report"
        Button4.UseVisualStyleBackColor = True
        ' 
        ' Button5
        ' 
        Button5.Location = New Point(997, 341)
        Button5.Name = "Button5"
        Button5.Size = New Size(242, 52)
        Button5.TabIndex = 6
        Button5.Text = "Staffs Accounts" & vbCrLf & vbCrLf & vbCrLf
        Button5.UseVisualStyleBackColor = True
        ' 
        ' Button6
        ' 
        Button6.Location = New Point(998, 391)
        Button6.Name = "Button6"
        Button6.Size = New Size(242, 44)
        Button6.TabIndex = 7
        Button6.Text = "Total No Of Payments" & vbCrLf & "=" & vbCrLf
        Button6.UseVisualStyleBackColor = True
        ' 
        ' Button7
        ' 
        Button7.Location = New Point(9, 570)
        Button7.Name = "Button7"
        Button7.Size = New Size(328, 44)
        Button7.TabIndex = 6
        Button7.Text = "Logout"
        Button7.UseVisualStyleBackColor = True
        ' 
        ' Button8
        ' 
        Button8.Location = New Point(9, 39)
        Button8.Name = "Button8"
        Button8.Size = New Size(328, 44)
        Button8.TabIndex = 7
        Button8.Text = "Administrator"
        Button8.UseVisualStyleBackColor = True
        ' 
        ' Button9
        ' 
        Button9.Location = New Point(998, 433)
        Button9.Name = "Button9"
        Button9.Size = New Size(242, 44)
        Button9.TabIndex = 8
        Button9.Text = "Total No Of Payments" & vbCrLf & "=" & vbCrLf
        Button9.UseVisualStyleBackColor = True
        ' 
        ' Button10
        ' 
        Button10.Location = New Point(998, 474)
        Button10.Name = "Button10"
        Button10.Size = New Size(242, 44)
        Button10.TabIndex = 9
        Button10.Text = "Total No Of Payments" & vbCrLf & "=" & vbCrLf
        Button10.UseVisualStyleBackColor = True
        ' 
        ' Button11
        ' 
        Button11.Location = New Point(404, 341)
        Button11.Name = "Button11"
        Button11.Size = New Size(576, 299)
        Button11.TabIndex = 10
        Button11.UseVisualStyleBackColor = True
        ' 
        ' Button12
        ' 
        Button12.BackColor = Color.Green
        Button12.Location = New Point(869, 372)
        Button12.Name = "Button12"
        Button12.Size = New Size(81, 35)
        Button12.TabIndex = 11
        Button12.Text = "Enable"
        Button12.UseVisualStyleBackColor = False
        ' 
        ' Button13
        ' 
        Button13.BackColor = Color.Green
        Button13.Location = New Point(869, 426)
        Button13.Name = "Button13"
        Button13.Size = New Size(81, 35)
        Button13.TabIndex = 12
        Button13.Text = "Enable"
        Button13.UseVisualStyleBackColor = False
        ' 
        ' Button14
        ' 
        Button14.BackColor = Color.Green
        Button14.Location = New Point(869, 483)
        Button14.Name = "Button14"
        Button14.Size = New Size(81, 35)
        Button14.TabIndex = 13
        Button14.Text = "Enable"
        Button14.UseVisualStyleBackColor = False
        ' 
        ' Button15
        ' 
        Button15.BackColor = Color.Green
        Button15.Location = New Point(869, 538)
        Button15.Name = "Button15"
        Button15.Size = New Size(81, 35)
        Button15.TabIndex = 14
        Button15.Text = "Enable"
        Button15.UseVisualStyleBackColor = False
        ' 
        ' Button16
        ' 
        Button16.BackColor = Color.Green
        Button16.Location = New Point(868, 589)
        Button16.Name = "Button16"
        Button16.Size = New Size(81, 35)
        Button16.TabIndex = 15
        Button16.Text = "Enable"
        Button16.UseVisualStyleBackColor = False
        ' 
        ' Form7
        ' 
        AutoScaleDimensions = New SizeF(10F, 25F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = SystemColors.ButtonHighlight
        ClientSize = New Size(1251, 652)
        Controls.Add(Button16)
        Controls.Add(Button15)
        Controls.Add(Button14)
        Controls.Add(Button13)
        Controls.Add(Button12)
        Controls.Add(Button11)
        Controls.Add(Button10)
        Controls.Add(Button9)
        Controls.Add(Button6)
        Controls.Add(Button5)
        Controls.Add(Button3)
        Controls.Add(Button2)
        Controls.Add(Button1)
        Controls.Add(Label1)
        Controls.Add(Panel1)
        Name = "Form7"
        Text = "Form7"
        Panel1.ResumeLayout(False)
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents Button9 As Button
    Friend WithEvents Button10 As Button
    Friend WithEvents Button11 As Button
    Friend WithEvents Button12 As Button
    Friend WithEvents Button13 As Button
    Friend WithEvents Button14 As Button
    Friend WithEvents Button15 As Button
    Friend WithEvents Button16 As Button
End Class
