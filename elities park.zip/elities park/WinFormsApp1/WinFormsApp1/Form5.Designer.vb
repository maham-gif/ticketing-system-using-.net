﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form5
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        FlowLayoutPanel1 = New FlowLayoutPanel()
        Panel1 = New Panel()
        Button1 = New Button()
        Panel2 = New Panel()
        Button2 = New Button()
        Button3 = New Button()
        Button4 = New Button()
        Button5 = New Button()
        Button6 = New Button()
        TextBox1 = New TextBox()
        Label1 = New Label()
        Button7 = New Button()
        Label2 = New Label()
        TextBox2 = New TextBox()
        TextBox3 = New TextBox()
        Label3 = New Label()
        Label4 = New Label()
        TextBox4 = New TextBox()
        Panel3 = New Panel()
        FlowLayoutPanel1.SuspendLayout()
        Panel1.SuspendLayout()
        SuspendLayout()
        ' 
        ' FlowLayoutPanel1
        ' 
        FlowLayoutPanel1.BackColor = Color.Green
        FlowLayoutPanel1.Controls.Add(Panel1)
        FlowLayoutPanel1.Controls.Add(Button2)
        FlowLayoutPanel1.Controls.Add(Button3)
        FlowLayoutPanel1.Controls.Add(Button4)
        FlowLayoutPanel1.Controls.Add(Button5)
        FlowLayoutPanel1.Location = New Point(0, 0)
        FlowLayoutPanel1.Name = "FlowLayoutPanel1"
        FlowLayoutPanel1.Size = New Size(337, 625)
        FlowLayoutPanel1.TabIndex = 0
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.Green
        Panel1.Controls.Add(Button1)
        Panel1.Controls.Add(Panel2)
        Panel1.Location = New Point(3, 3)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(1078, 124)
        Panel1.TabIndex = 1
        ' 
        ' Button1
        ' 
        Button1.BackColor = Color.Green
        Button1.FlatStyle = FlatStyle.Flat
        Button1.Font = New Font("Segoe UI", 15F)
        Button1.Location = New Point(-13, -3)
        Button1.Name = "Button1"
        Button1.Size = New Size(347, 127)
        Button1.TabIndex = 1
        Button1.Text = "Settings"
        Button1.UseVisualStyleBackColor = False
        ' 
        ' Panel2
        ' 
        Panel2.Location = New Point(334, 51)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(1078, 571)
        Panel2.TabIndex = 2
        ' 
        ' Button2
        ' 
        Button2.BackColor = Color.Green
        Button2.FlatStyle = FlatStyle.Flat
        Button2.Font = New Font("Segoe UI", 15F)
        Button2.Location = New Point(3, 133)
        Button2.Name = "Button2"
        Button2.Size = New Size(334, 112)
        Button2.TabIndex = 2
        Button2.Text = "Accounts"
        Button2.UseVisualStyleBackColor = False
        ' 
        ' Button3
        ' 
        Button3.BackColor = Color.Green
        Button3.FlatStyle = FlatStyle.Flat
        Button3.Font = New Font("Segoe UI", 15F)
        Button3.Location = New Point(3, 251)
        Button3.Name = "Button3"
        Button3.Size = New Size(334, 112)
        Button3.TabIndex = 3
        Button3.Text = "Privacy"
        Button3.UseVisualStyleBackColor = False
        ' 
        ' Button4
        ' 
        Button4.BackColor = Color.Green
        Button4.FlatStyle = FlatStyle.Flat
        Button4.Font = New Font("Segoe UI", 15F)
        Button4.Location = New Point(3, 369)
        Button4.Name = "Button4"
        Button4.Size = New Size(334, 112)
        Button4.TabIndex = 4
        Button4.Text = "Security"
        Button4.UseVisualStyleBackColor = False
        ' 
        ' Button5
        ' 
        Button5.BackColor = Color.Green
        Button5.FlatStyle = FlatStyle.Flat
        Button5.Font = New Font("Segoe UI", 15F)
        Button5.Location = New Point(3, 487)
        Button5.Name = "Button5"
        Button5.Size = New Size(334, 112)
        Button5.TabIndex = 5
        Button5.Text = "Logout"
        Button5.UseVisualStyleBackColor = False
        ' 
        ' Button6
        ' 
        Button6.BackColor = Color.White
        Button6.FlatStyle = FlatStyle.Flat
        Button6.Font = New Font("Segoe UI", 15F)
        Button6.Location = New Point(392, 86)
        Button6.Name = "Button6"
        Button6.Size = New Size(334, 112)
        Button6.TabIndex = 6
        Button6.Text = "Account Settings"
        Button6.UseVisualStyleBackColor = False
        ' 
        ' TextBox1
        ' 
        TextBox1.Location = New Point(386, 306)
        TextBox1.Name = "TextBox1"
        TextBox1.Size = New Size(228, 31)
        TextBox1.TabIndex = 7
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(389, 261)
        Label1.Name = "Label1"
        Label1.Size = New Size(63, 25)
        Label1.TabIndex = 8
        Label1.Text = "Label1"
        ' 
        ' Button7
        ' 
        Button7.Location = New Point(879, 515)
        Button7.Name = "Button7"
        Button7.Size = New Size(112, 34)
        Button7.TabIndex = 9
        Button7.Text = "update"
        Button7.UseVisualStyleBackColor = True
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(763, 261)
        Label2.Name = "Label2"
        Label2.Size = New Size(63, 25)
        Label2.TabIndex = 10
        Label2.Text = "Label2"
        ' 
        ' TextBox2
        ' 
        TextBox2.Location = New Point(763, 306)
        TextBox2.Name = "TextBox2"
        TextBox2.Size = New Size(228, 31)
        TextBox2.TabIndex = 11
        ' 
        ' TextBox3
        ' 
        TextBox3.Location = New Point(763, 431)
        TextBox3.Name = "TextBox3"
        TextBox3.Size = New Size(228, 31)
        TextBox3.TabIndex = 15
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(763, 386)
        Label3.Name = "Label3"
        Label3.Size = New Size(63, 25)
        Label3.TabIndex = 14
        Label3.Text = "Label3"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Location = New Point(389, 386)
        Label4.Name = "Label4"
        Label4.Size = New Size(63, 25)
        Label4.TabIndex = 13
        Label4.Text = "Label4"
        ' 
        ' TextBox4
        ' 
        TextBox4.Location = New Point(386, 431)
        TextBox4.Name = "TextBox4"
        TextBox4.Size = New Size(228, 31)
        TextBox4.TabIndex = 12
        ' 
        ' Panel3
        ' 
        Panel3.Location = New Point(356, 34)
        Panel3.Name = "Panel3"
        Panel3.Size = New Size(697, 554)
        Panel3.TabIndex = 16
        ' 
        ' Form5
        ' 
        AutoScaleDimensions = New SizeF(10F, 25F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = SystemColors.ButtonHighlight
        ClientSize = New Size(1083, 627)
        Controls.Add(TextBox3)
        Controls.Add(Label3)
        Controls.Add(Label4)
        Controls.Add(TextBox4)
        Controls.Add(TextBox2)
        Controls.Add(Label2)
        Controls.Add(Button7)
        Controls.Add(Label1)
        Controls.Add(TextBox1)
        Controls.Add(FlowLayoutPanel1)
        Controls.Add(Button6)
        Controls.Add(Panel3)
        Name = "Form5"
        Text = "Form5"
        FlowLayoutPanel1.ResumeLayout(False)
        Panel1.ResumeLayout(False)
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents FlowLayoutPanel1 As FlowLayoutPanel
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Button1 As Button
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Button7 As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents Panel3 As Panel
End Class
